var searchData=
[
  ['getpinmode_59',['getPinMode',['../classfirmata_1_1_firmata_class.html#a0c434227456ce2ba97b3b1142c329f96',1,'firmata::FirmataClass']]],
  ['getpinstate_60',['getPinState',['../classfirmata_1_1_firmata_class.html#acf5d4f460b9a2298653d4a71de918dfe',1,'firmata::FirmataClass']]]
];
